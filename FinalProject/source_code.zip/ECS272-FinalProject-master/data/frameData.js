var frameData = {
	"name": "AllFrames",
	"children": [
		{
			"name": "Cause",
			"children": [
				{"name": "FossilFuels", "value": 3938},
				{"name": "PlasticsBurning", "value": 3938},
				{"name": "HumanConsumption", "value": 5176},
				{"name": "Deforestation", "value": 449},
				{"name": "TravelPatterns", "value": 5593}
			]
		},
		{
			"name": "Problem",
			"children": [
				{"name": "OtherHumanFactors", "value": 17010},
				{"name": "ProbThreatEnvironment", "value": 5842},
				{"name": "ProbThreatHealth", "value": 1041},
				{"name": "ProbThreatEconomic", "value": 9201},
				{"name": "ProbThreatFood", "value": 19975},
				{"name": "ProbThreatWater", "value": 1116},
				{"name": "ProbThreatSecurity", "value": 6006},
				{"name": "ProbThreatSocialUnrest", "value": 6006},
				{"name": "ProbThreatGenMultiplex", "value": 6006}
			]
		},
		{
			"name": "Solution",
			"children": [
				{"name": "CleanPowerPlants", "value": 1759},
				{"name": "ControlMethaneLeaks", "value": 2165},
				{"name": "LowerEmissions", "value": 586},
				{"name": "EnhanceEnergyEfficiency", "value": 3331},
				{"name": "GreenerFarming", "value": 772},
				{"name": "GeopoliticalConsensus", "value": 3322}
			]
		},
		{
			"name": "Motivation",
			"children": [
				{"name": "Benefits", "value": 8833},
				{"name": "Difficulty", "value": 1732},
				{"name": "IndirectEffects", "value": 3623},
				{"name": "LongTermView", "value": 10066},
				{"name": "ShortTermView", "value": 10066}
			]
		}
	]
}