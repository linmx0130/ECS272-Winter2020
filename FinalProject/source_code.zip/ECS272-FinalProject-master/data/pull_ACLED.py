import csv
import json
def read_data(filename):
    out = []
    with open(filename) as f:
        reader = csv.DictReader(f)
        for item in reader:
            out.append({'date': item['event_date'],
                        'type': item['event_type'],
                        'actors': [item['actor1'], item['actor2']],
                        'notes': item['notes'],
                        'location': item['location'],
                        'latitude': item['latitude'],
                        'longitude': item['longitude'],
                        'country': item['country'],
                        })
    return out

data = []
data.extend(read_data('ACLEDAfrica.csv'))
data.extend(read_data('ACLEDOthers.csv'))
with open('clean_ACLED.json', 'w') as f:
    json.dump(data, f, indent=4)
