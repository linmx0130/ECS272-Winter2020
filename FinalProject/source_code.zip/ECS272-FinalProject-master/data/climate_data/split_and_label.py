import nltk
import json
import re
from tqdm import tqdm

def load_frames():
    with open('RSSFrames.json') as f:
        frames = json.load(f)
    return frames

def predict_frame(sent, frames):
    prediction = None
    score = 0
    if 'children' in frames:
        for ch in frames['children']:
            cpred, cscore = predict_frame(sent, ch)
            if cscore > score:
                score = cscore
                prediction = cpred
    else:
        prediction = frames["name"]
        if "keywords" in frames:
            # count keywords
            sent_words = set(nltk.word_tokenize(sent))
            for k in frames['keywords']:
                k = k.lower()
                if k in sent_words:
                    score += frames['value']
        elif "regex" in frames:
            for reg in frames["regex"]:
                if len(re.findall(reg, sent)) > 0:
                    score += frames['value']
    return prediction, score

def generate_labels_for_article(article, frames):
    text = article['content']
    sent_text = nltk.sent_tokenize(text)
    labels = dict()
    for sent in sent_text:
        pred, score = predict_frame(sent.lower(), frames)
        if score > 0:
            if not (pred in labels):
                labels[pred] = 0
            labels[pred] += score
    return labels


frames = load_frames()
with open('climate_articles_labeled.json') as f:
    data = json.load(f)

for item in tqdm(data):
    labels = generate_labels_for_article(item, frames)
    item['frame_label'] = labels


with open('climate_articles_labeled.json', 'w') as f:
    json.dump(data, f, indent=4)
