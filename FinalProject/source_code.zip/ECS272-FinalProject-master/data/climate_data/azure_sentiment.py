subscription_key = '<key>'
endpoint = '<endpoint>'
import json
from azure.cognitiveservices.language.textanalytics import TextAnalyticsClient
from msrest.authentication import CognitiveServicesCredentials

def authenticateClient():
    credentials = CognitiveServicesCredentials(subscription_key)
    text_analytics_client = TextAnalyticsClient(
        endpoint=endpoint, credentials=credentials)
    return text_analytics_client

def sentiment(documents):
    client = authenticateClient()
    req_docs = []
    ret_scores = []
    for idx, item in enumerate(documents):
        if len(item) > 4000:
            item = item[:4000]
        req_docs.append({'id': str(idx + 1), 'language': 'en',
                         'text': item})
    response = client.sentiment(documents = req_docs)
    ret_docs = response.documents
    for sc in ret_docs:
        ret_scores.append((sc.id, sc.score))
    return ret_scores

with open('climate_articles_labeled.json') as f:
    data = json.load(f)

total_batch = len(data) // 5 + 1
for idx in range(total_batch):
    print('{} / {}'.format(idx, total_batch))
    piece = data[idx * 5: idx * 5 + 5]
    contents = [t['content'] for t in piece]
    ret_scores = sentiment(contents)
    for jdx in range(len(piece)):
        piece[jdx]['sentiment'] = ret_scores[jdx][1]
    with open('climate_articles_labeled_sent.json', 'w') as f:
        json.dump(data, f)

