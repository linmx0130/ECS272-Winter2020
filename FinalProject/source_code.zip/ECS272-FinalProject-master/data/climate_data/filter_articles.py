import csv
import nltk
import json

def load_keywords(filename):
    keywords = []
    with open(filename) as f:
        for item in f.readlines():
            if len(item.strip()) == 0:
                continue
            keywords.append(item.strip())
    return keywords

def match_keywords(content, keywords):
    for k in keywords:
        if k in content:
            return True
    return False

keywords = load_keywords('keywords')
print(csv.field_size_limit(524288))
def filter_articles(filename, keywords):
    found = 0
    total = 0
    ret = []
    with open(filename) as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            total += 1
            title = row[2].lower()
            content = row[8].lower()
            if match_keywords(title + ' >>>>> ' + content, keywords):
                found += 1
                ret.append(row)
    print("%d / %d" % (found, total))
    return ret

def wrap_data(row):
    #,id,title,publication,author,date,year,month,url,content
    return {'id': row[1],
            'title': row[2],
            'publication': row[3],
            'author': row[4],
            'date': row[5],
            'year': row[6],
            'month': row[7],
            'url': row[8],
            'content': row[9]}

d1 = filter_articles('articles1.csv', keywords)
d1.extend(filter_articles('articles2.csv', keywords))
d1.extend(filter_articles('articles3.csv', keywords))
d1 = [wrap_data(t) for t in d1]

with open('climate_articles.json', 'w') as f:
    json.dump(d1, f, indent=4)
