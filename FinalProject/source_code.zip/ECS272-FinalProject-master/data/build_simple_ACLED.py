import json

with open('clean_ACLED.json') as f:
    data = json.load(f)

new_data = [{'event_date': t['date'], 'latitude': t['latitude'], 'longitude': t['longitude'], 'event_type': t['type'], 'country': t['country']} for t in data]
with open('simple_ACLED.json', 'w') as f:
    json.dump(new_data, f, indent=4)
