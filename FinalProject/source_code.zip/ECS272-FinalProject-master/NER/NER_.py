# pip install spacy
#downloads the model for the specified language (English)
# !python -m spacy download en_core_web_sm

import spacy
import json
import en_core_web_sm
import tqdm

#loads the model as snlp
snlp = spacy.load("en_core_web_sm")
with open("../data/climate_data/climate_articles_labeled.json", "r") as read_file:
    data = json.load(read_file)

with open('country_list') as f:
    country_list = f.readlines()
    country_list = set([t.strip() for t in country_list])

new_data = []
for item in tqdm.tqdm(data):
    doc = snlp(item['content'])
    first_loc = None
    persons = set()
    orgs = set()
    locs = set()
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            persons.add(ent.text)
        if ent.label_ == 'ORG':
            orgs.add(ent.text)
        if ent.label_ in ['LOC', 'GPE']:
            if ent.text == 'Earth':
                continue
            locs.add(ent.text)
            if first_loc is None:
                if ent.text in country_list:
                    first_loc = ent.text
    persons = list(persons)
    orgs = list(orgs)
    locs = list(locs)
    item['ner'] = {'persons': persons, 'orgs': orgs, 'locs': locs}
    if first_loc is None:
        first_loc = "the United States"
    item['location'] = first_loc
    new_data.append(item)

with open('NER.json', 'w') as outfile:
    json.dump(new_data, outfile, indent=4)
