# pip install spacy
#downloads the model for the specified language (English)
# !python -m spacy download en_core_web_sm

import spacy
import json
import en_core_web_sm
import tqdm

#loads the model as snlp
snlp = spacy.load("en_core_web_sm")
with open("../data/clean_ACLED.json", "r") as read_file:
    data = json.load(read_file)

new_data = []
for item in tqdm.tqdm(data):
    doc = snlp(item['notes'])
    persons = set()
    orgs = set()
    locs = set()
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            persons.add(ent.text)
        if ent.label_ == 'ORG':
            orgs.add(ent.text)
        if ent.label_ in ['LOC', 'GPE']:
            if ent.text == 'Earth':
                continue
            locs.add(ent.text)
    persons = list(persons)
    orgs = list(orgs)
    locs = list(locs)
    item['ner'] = {'persons': persons, 'orgs': orgs, 'locs': locs}
    new_data.append(item)

with open('NER.json', 'w') as outfile:
    json.dump(new_data, outfile, indent=4)
