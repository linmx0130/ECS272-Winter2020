//Original StartTime and EndTime

var OriStartTime = new Date(2016,1,1);
var OriEndTime = new Date(2017,6,21);

//Record Overall Parameters
var currentFrame = document.getElementById("currentFrame");
currentFrame.innerHTML = "AllFrames";
var currentEventType = document.getElementById("currentEventType");
currentEventType.innerHTML = "AllEvents";
var currentStartTime = document.getElementById("currentStartTime");
currentStartTime.innerHTML = OriStartTime;
var currentEndTime = document.getElementById("currentEndTime");
currentEndTime.innerHTML = OriEndTime;
var currentCountry = document.getElementById("currentCountry");
currentCountry.innerHTML = "";

var listCheck = document.getElementById("LISTCheck");
var PERSONCheck = document.getElementById("PERSONCheck");
var LOCATIONCheck = document.getElementById("LOCATIONCheck");
var ORGANIZATIONCheck = document.getElementById("ORGANIZATIONCheck");

var ACLEDContent = d3.select("#ACLEDContent");
var RSSContent = d3.select("#RSSContent");
//Frame donut control 
var format = d3.format(",d");
var width = 200;
var radius = width/6;

const svg = d3.select("#RSSDonut").append("svg")
	.attr("viewBox", [0, 0, width, width])
	.style("font", "13px sans-serif")
	.style("margin-top", "10px");

const g = svg.append("g")
	.attr("transform", `translate(${width / 2},${width / 2})`);

const label = g.append("g")
	.attr("pointer-events", "none")
	.attr("text-anchor", "middle")
	.style("user-select", "none")
	.append("text")
	.attr("dy", "0.35em")
	.text("All Frames");

var colorParent = d3.scaleOrdinal().domain(["Cause", "Problem", "Solution", "Motivation"])
		.range(d3.schemeCategory10);

var FrameStructure = [
	{
		"name": "Cause",
		"children": ["OtherCause", "FossilFuels", "PlasticsBurning", "HumanConsumption", "TravelPatterns", "PolicyReason"]
	},
	{
		"name": "Problem",
		"children": ["OtherProblem", "ProbThreatHealth", "ProbThreatEconomic", "ProbThreatFood", "ProbThreatSecurity"]
	},
	{
		"name": "Solution",
		"children": ["OtherSolution", "CleanPowerPlants", "LowerEmissions", "EnhanceEnergyEfficiency", "GreenerFarming",
		"GeopoliticalConsensus"]
	},
	{
		"name": "Motivation",
		"children": ["Benefits", "Difficulty", "IndirectEffects", "LongTermView", "ShortTermView", "OtherMotivation"]
	}
]

updateFrameDonut(OriStartTime, OriEndTime);

function updateFrameDonut(startTime, endTime)
{

	d3.json("timeline/view_through_time")
	.then( newsData => {
		console.log(newsData);

		var data = {
			"name": "AllFrames",
			"children": [
			{
				"name": "Cause",
				"children": [
					{"name": "OtherCause", "value": 0},
					{"name": "FossilFuels", "value": 0},
					{"name": "PlasticsBurning", "value": 0},
					{"name": "HumanConsumption", "value": 0},
					{"name": "TravelPatterns", "value": 0},
					{"name": "PolicyReason", "value": 0}
				]
			},
			{
				"name": "Problem",
				"children": [
					{"name": "OtherProblem", "value": 0},
					{"name": "ProbThreatHealth", "value": 0},
					{"name": "ProbThreatEconomic", "value": 0},
					{"name": "ProbThreatFood", "value": 0},
					{"name": "ProbThreatSecurity", "value": 0}
				]
			},
			{
				"name": "Solution",
				"children": [
					{"name": "OtherSolution", "value": 0},
					{"name": "CleanPowerPlants", "value": 0},
					{"name": "LowerEmissions", "value": 0},
					{"name": "EnhanceEnergyEfficiency", "value": 0},
					{"name": "GreenerFarming", "value": 0},
					{"name": "GeopoliticalConsensus", "value": 0}
				]
			},
			{
				"name": "Motivation",
				"children": [
					{"name": "Benefits", "value": 0},
					{"name": "Difficulty", "value": 0},
					{"name": "IndirectEffects", "value": 0},
					{"name": "LongTermView", "value": 0},
					{"name": "ShortTermView", "value": 0},
					{"name": "OtherMotivation", "value": 0}
				]
			}
		]}

		for (var i=0; i<newsData.length; i++)
		{
			var tmpTime = new Date(newsData[i].date);
				if (tmpTime.getTime() >= startTime.getTime() && tmpTime.getTime() <= endTime.getTime())
				{
					for (var k=0; k<Object.keys(newsData[i].frame_labels).length; k++)
					{
						for (j=0; j<data.children.length; j++)
						{
							var flag = 0;
							for (var m=0; m<data.children[j].children.length; m++)
							{
								if (data.children[j].children[m].name == Object.keys(newsData[i].frame_labels)[k])
								{
									data.children[j].children[m].value = data.children[j].children[m].value+newsData[i].frame_labels[Object.keys(newsData[i].frame_labels)[k]];
									flag=1;
									break;
								}
							}
							if (flag == 1) break;
						}
					}
				}
		}
		console.log(data);

		var colorCause = d3.scaleOrdinal().domain(data.children[0].children.map(d => d.name))
		    .range(d3.schemeBlues[6]);

		var colorProblem = d3.scaleOrdinal().domain(data.children[1].children.map(d => d.name))
		    .range(d3.schemeOranges[9]);

		var colorSolution = d3.scaleOrdinal().domain(data.children[2].children.map(d => d.name))
		    .range(d3.schemeGreens[7]);

		var colorMotivation = d3.scaleOrdinal().domain(data.children[3].children.map(d => d.name))
		    .range(d3.schemeReds[6]);

		var arc = d3.arc()
		.startAngle(d => d.x0)
		.endAngle(d => d.x1)
		.padAngle(d => Math.min((d.x1 - d.x0) / 2, 0.02))
		.padRadius(radius * 1.5)
		.innerRadius(d => d.y0 * radius)
		.outerRadius(d => Math.max(d.y0 * radius, d.y1 * radius - 1));

		partition = data => {
			const root = d3.hierarchy(data)
				.sum(d => d.value)
			return d3.partition()
				.size([2 * Math.PI, root.height + 1])
				(root);
		}

		const root = partition(data);

		root.each(d => d.current = d);

		const path = g.selectAll("path")
			.data(root.descendants().slice(1))
			.join("path")
			.attr("fill", d => { 
				if (d.depth == 1)
					return colorParent(d.data.name); 
				else
				{
					if (d.parent.data.name == "Cause")
					return colorCause(d.data.name);
					if (d.parent.data.name == "Problem")
						return colorProblem(d.data.name);
					if (d.parent.data.name == "Solution")
						return colorSolution(d.data.name);
					if (d.parent.data.name == "Motivation")
						return colorMotivation(d.data.name);
				}
					
			})
			.attr("d", d => arc(d.current));

		path.filter(d => d.current)
			.style("cursor", "pointer")
			.on("click", clicked);

		path.append("title")
			.text(d => `${d.ancestors().map(d => d.data.name).reverse().join("/")}\n${format(d.value)}`);

		const parent = g.append("circle")
			.datum(root)
			.attr("r", radius)
			.attr("fill", "none")
			.attr("pointer-events", "all")
			.on("click", clicked);

		function clicked(p) {
			const t = g.transition().duration(750);
			if(p.current.data.name == "AllFrames")
			{
				path.transition(t)
				.attr("fill-opacity", 1.0)
				currentFrame.innerHTML = "AllFrames";
				updateEventDots("AllFrames", currentEventType.innerHTML, startTime, endTime);
			}
			else
			{
				currentFrame.innerHTML = p.current.data.name;
				updateEventDots(p.current.data.name, currentEventType.innerHTML, startTime, endTime);
				path.transition(t).
				attr("fill-opacity", d => { 
					if (d.data.name == p.current.data.name)
					{
						console.log(d.data.name);
						return 1.0; 
					}
					else
					{
						return 0.4;
					}
					
				})
			}
		}

	});

}

var ACLEDcolor = d3.scaleOrdinal()
	  .domain(["Riots", "Violence against civilians", "Strategic developments", "Battles", "Protests", "Explosions/Remote violence"])
	  .range(d3.schemeSet3);

//ACLED donut control
const svgACLED = d3.select("#ACLEDDonut").append("svg")
	.style("font", "15px sans-serif")
	.attr("width", width)
    .attr("height", width)
	.style("margin-top", "10px")

const ACLEDg = svgACLED.append("g")
	.attr("transform", `translate(${width / 2},${width / 2})`);

updateACLEDDonut(OriStartTime, OriEndTime);

const ACLEDlabel = ACLEDg.append("g")
	.attr("pointer-events", "none")
	.attr("text-anchor", "middle")
	.style("user-select", "none")
	.append("text")
	.attr("dy", "0.35em")
	.text("All Event Type");

function updateACLEDDonut(startTime, endTime)
{
	d3.json('../data/simple_ACLED.json')
	.then(ACLEDUnit => {

		var ACLEDevent = [];
		for (var i=0; i<ACLEDUnit.length; i=i+8)
		{
			var tmpTime = new Date(ACLEDUnit[i].event_date);
			if (tmpTime.getTime() >= startTime.getTime() && tmpTime.getTime() <= endTime.getTime())
			{
				ACLEDevent.push(ACLEDUnit[i].event_type);
			}
		}

		var ACLEDdata = new Array();
		for (var i=0; i<ACLEDevent.length; i++)
		{
			if (ACLEDdata.hasOwnProperty(ACLEDevent[i]))
			{
				ACLEDdata[ACLEDevent[i]] = ACLEDdata[ACLEDevent[i]]+1;
			}
			else
			{
				ACLEDdata[ACLEDevent[i]] = 1;
			}
		}

	var pie = d3.pie()
	  .value(function(d) {return d.value; })
	var data_ready = pie(d3.entries(ACLEDdata))

	console.log(data_ready);

	const pathACLED = ACLEDg
	  .selectAll('path')
	  .data(data_ready)
	  .join("path")
	  .attr('d', d3.arc()
	    .innerRadius(50)         // This is the size of the donut hole
	    .outerRadius(width/2 - 10)
	    .padAngle(0.01)
	  )
	  .attr('fill', function(d){ return(ACLEDcolor(d.data.key)) });

	pathACLED.filter(d => d)
		.style("cursor", "pointer")
		.on("click", ACLEDclicked);

	pathACLED.append("title")
		.text(d => `${"AllTypeEvent/"+d.data.key}\n${format(d.value)}`);

	const ACLEDparent = ACLEDg.append("circle")
		.datum(0)
		.attr("r", radius)
		.attr("fill", "none")
		.attr("pointer-events", "all")
		.on("click", ACLEDclicked);

	function ACLEDclicked (p) {
		const t = g.transition().duration(750);
		if(!p.data)
		{
			currentEventType.innerHTML = "AllEvents";
			updateEventDots(currentFrame.innerHTML, "AllEvents", startTime, endTime);
			pathACLED.transition(t)
			.attr("fill-opacity", 1.0)
		}
		else
		{
			currentEventType.innerHTML = p.data.key;
			updateEventDots(currentFrame.innerHTML, p.data.key, startTime, endTime);
			pathACLED.transition(t).
			attr("fill-opacity", d => { 
				if (d.data.key == p.data.key)
				{
					console.log(p.data.key);
					return 1.0; 
				}
				else
				{
					return 0.4;
				}
				
			})
		}
	}
	});
}

//timeLine
var width2 = 1000;
var height = 70;
var margin = ({top: 10, right: 30, bottom: 25, left: 30});

const svg2 = d3.select("#timeVolume").append("svg")
	.attr("viewBox", [0, 0, width2, height]);

d3.json('../data/simple_ACLED.json')
.then(ACLEDUnit => {
	var ACLEDdate = [];
	for (var i=0; i<ACLEDUnit.length; i=i+8)
	{
		ACLEDdate.push(new Date(ACLEDUnit[i].event_date));
	}
	//console.log(ACLEDdate);
	var data2 = [];
	for (var i=0; i<ACLEDdate.length; i++)
	{
		var find = 0;
		for (var j=0; j<data2.length; j++)
		{
			if (data2[j].date.getTime() == ACLEDdate[i].getTime())
			{
				find = 1;
				data2[j].value = data2[j].value+1;
				break;
			}
		}
		if (find == 0)
		{
			data2.push({date: ACLEDdate[i], value: 1});
		}
	}
	console.log(data2);

	var line = d3.line()
		.defined(d => !isNaN(d.value))
	    .x(d => x(d.date))
	    .y(d => y(d.value));

	x = d3.scaleUtc()
	    .domain(d3.extent(data2, d => d.date))
	    .range([margin.left, width2 - margin.right])

	y = d3.scaleLinear()
	    .domain([0, d3.max(data2, d => d.value)]).nice()
	    .range([height - margin.bottom, margin.top])

	xAxis = g => g
	    .attr("transform", `translate(0,${height - margin.bottom})`)
	    .call(d3.axisBottom(x).ticks(width2 / 80).tickSizeOuter(0))

	yAxis = g => g
	    .attr("transform", `translate(${margin.left},0)`)
	    .call(d3.axisLeft(y).ticks(4))
	    .call(g => g.select(".tick:last-of-type text").clone()
	        .attr("x", 3)
	        .attr("text-anchor", "start")
	        .attr("font-weight", "bold")
	        .text(data2.y))

	svg2
		.call( d3.brushX()
	    	.extent( [ [margin.left, margin.top], [width2-margin.right, height-margin.bottom] ] )  
	    	.on("brush", onBrush)
	        .on("end", function() {
	            extent = d3.event.selection;    
	            if (extent!==null) {
	                HTimeLine.setDateRange(x.invert(extent[0]), x.invert(extent[1]));
	                HTimeLine.clearFocusBox();

	                updateACLEDDonut(x.invert(extent[0]), x.invert(extent[1]));
	                updateFrameDonut(x.invert(extent[0]), x.invert(extent[1]));
	               	updateEventDots(currentFrame.innerHTML, currentEventType.innerHTML,x.invert(extent[0]), x.invert(extent[1]));
	               	currentStartTime.innerHTML = x.invert(extent[0]);
	               	currentEndTime.innerHTML = x.invert(extent[1]);
	            }
	            else {
	            	HTimeLine.setDateRange(OriStartTime, OriEndTime);
	                HTimeLine.clearFocusBox();
	            	updateACLEDDonut(OriStartTime, OriEndTime);
	                updateFrameDonut(OriStartTime, OriEndTime);
	               	updateEventDots(currentFrame.innerHTML, currentEventType.innerHTML, OriStartTime, OriEndTime);
	               	currentStartTime.innerHTML = OriStartTime;
	               	currentEndTime.innerHTML = OriEndTime;
	            }
	        }));


	svg2.append("g")
	  	.call(xAxis);

	svg2.append("g")
	  	.call(yAxis);

	svg2.append("path")
		  .datum(data2)
		  .attr("fill", "none")
		  .attr("stroke", "black")
		  .attr("stroke-width", 1.5)
		  .attr("stroke-linejoin", "round")
		  .attr("stroke-linecap", "round")
		  .style("stroke-dasharray", ("3, 3")) 
		  .attr("d", line);

});

function onBrush() {
    extent = d3.event.selection;    
    if (extent === null) {
        HTimeLine.clearFocusBox();
    }else{
        HTimeLine.setFocusBox(x.invert(extent[0]), x.invert(extent[1]));
    }
}

//map
var corner1 =  L.latLng(-90, -180);
var corner2 = L.latLng(90, 180);	
var bounds = L.latLngBounds(corner1, corner2);

var countryPieCharts = L.layerGroup();

updatePieLayer(OriStartTime, OriEndTime);

function updatePieLayer(startTime, endTime)
{
	countryPieCharts.eachLayer(function (layer) {
		if (layer != grayLayer)
		{
			countryPieCharts.removeLayer(layer);
		}
	});

	d3.json('data/country_capital.json')
	.then(countryInfo => {
		d3.json('data/climate_articles_labeled.json')
		.then(news => {
			console.log(news);
			for (var i=0; i<countryInfo.length; i++) {
				var flag = 0;
				var Cause = 0;
				var Problem = 0;
				var Solution = 0;
				var Motivation = 0;
				var Radius = 0;
				for (var j=0; j<news.length; j++)
				{
					var tmpTime = new Date(news[j].date);
					if (news[j].location == countryInfo[i].CountryName && tmpTime.getTime() >= startTime.getTime() && tmpTime.getTime() <= endTime.getTime())
					{
						flag = 1;
						for (var key of Object.keys(news[j].frame_label))
						{
							//console.log(key);
							if (FrameMap(key) == "Cause") {Cause = Cause + news[j].frame_label[key];}
							if (FrameMap(key) == "Problem") {Problem = Problem + news[j].frame_label[key];}
							if (FrameMap(key) == "Solution") {Solution = Solution + news[j].frame_label[key];}
							if (FrameMap(key) == "Motivation") {Motivation + news[j].frame_label[key];}
						}

					}
				}
				if (countryInfo[i].CountryName == "China") Radius = (Cause+Problem+Solution+Motivation)/20;
				else Radius = (Cause+Problem+Solution+Motivation)/5;
				var options = {
					data: {
						'Cause': Cause,
						'Problem': Problem,
						'Solution': Solution,
						'Motivation': Motivation
					},
					chartOptions: {
						'Cause': {
							fillColor: colorParent("Cause")
						},
						'Problem': {
							fillColor: colorParent("Problem")
						},
						'Solution': {
							fillColor: colorParent("Solution")
						},
						'Motivation': {
							fillColor: colorParent("Motivation")
						}
					},
					radius: Radius,
					fillOpacity: 0.7
				}

				if (flag == 1)
				{
					//console.log(options);
					var pieChartMarker = new L.PieChartMarker(new L.LatLng(countryInfo[i].CapitalLatitude, countryInfo[i].CapitalLongitude), options);
					pieChartMarker.addTo(countryPieCharts);
				}
				
			}
		});
	});
	
	console.log(countryPieCharts);
	
}

var grayLayer = L.tileLayer.grayscale('http://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: 'Map data &copy; <a href="http://openstreetmap.org/">OpenStreetMap</a> contributors'
    });

var map = L.map('mapView', { fadeAnimation: false, maxBounds: bounds }).setView([25, -4], 3);

updateEventDots("AllFrames", "AllEvents", new Date(2016,1,1), new Date(2017,6,21))

var overlayMaps = {
    "CountryFramePie": countryPieCharts
};

var baseMaps = {
    "Grayscale": grayLayer
};

L.control.layers(baseMaps, overlayMaps).addTo(map);

grayLayer.addTo(map);

function onEachFeature(feature, layer) {
    layer.on("click", function(e) {

    	updateWordCloud(currentEventType.innerHTML, feature.properties.name, currentStartTime.innerHTML, currentEndTime.innerHTML)
    });
    if (feature.properties && feature.properties.name) {
        layer.bindPopup(feature.properties.name);
    }
}

function getColor(d) {
    return d > 1000 ? '#800026' :
           d > 500  ? '#BD0026' :
           d > 200  ? '#E31A1C' :
           d > 100  ? '#FC4E2A' :
           d > 50   ? '#FD8D3C' :
           d > 20   ? '#FEB24C' :
           d > 10   ? '#FED976' :
                      '#FFEDA0';
}

function style(feature) {
	//console.log(feature.properties.frames);
    return {
        "fillColor": getColor(feature.properties.frames),
        "fillOpacity": 0.5,
        "color": "#000",
		"weight": 2,
		"dashArray": '5',
		"opacity": 0.4
    };
}

var legend = L.control({position: 'bottomright'});

legend.onAdd = function (map) {

    var div = L.DomUtil.create('div', 'info legend'),
        grades = [0, 10, 20, 50, 100, 200, 500, 1000],
        labels = [];

    // loop through our density intervals and generate a label with a colored square for each interval
    for (var i = 0; i < grades.length; i++) {
        div.innerHTML +=
            '<i style="background:' + getColor(grades[i] + 1) + '"></i> ' +
            '<p>' + grades[i] + (grades[i + 1] ? '&ndash;' + grades[i + 1] + '<br>' : '+') + '</p>';
    }

    return div;
};

legend.addTo(map);

function updateEventDots(frame, event, startTime, endTime) {
	map.eachLayer(function (layer) {
		if (layer != grayLayer)
		{
			map.removeLayer(layer);
		}
	});

	d3.json('data/world-countries.json')
	.then(topology => {
		// create data by selecting two columns from csv 
		var geojson = topojson.feature(topology, topology.objects.countries1);

		d3.json('data/climate_articles_labeled.json')
		.then(news => {
			if (frame == "AllFrames")
			{
				for (var i=0; i<geojson.features.length; i++)
				{
					geojson.features[i].properties.frames = 0;
					for (var j=0; j<news.length; j++)
					{
						var tmpTime = new Date(news[j].date);
						if (news[j].location == geojson.features[i].properties.name && tmpTime.getTime() >= startTime.getTime() && tmpTime.getTime() <= endTime.getTime() )
						{
							for (var value of Object.values(news[j].frame_label))
							geojson.features[i].properties.frames = geojson.features[i].properties.frames + value;
						}
					}
				}
			}
			else 
			{
				for (var i=0; i<geojson.features.length; i++)
				{
					geojson.features[i].properties.frames = 0;
					for (var j=0; j<news.length; j++)
					{
						var tmpTime = new Date(news[j].date);
						if (news[j].location == geojson.features[i].properties.name && tmpTime.getTime() >= startTime.getTime() && tmpTime.getTime() <= endTime.getTime())
						{
							for (var key of Object.keys(news[j].frame_label))
							{
								if (FrameMap(key) == frame || key == frame)
								{
									geojson.features[i].properties.frames = geojson.features[i].properties.frames + news[j].frame_label[key];
								}
							}
							
						}
					}
				}
			}

			L.geoJson(geojson, {
				style: style,
				onEachFeature: onEachFeature
			}).addTo(map);

		});
		drawDots(event, startTime, endTime)

	});

}

function drawDots(event, startTime, endTime)
{
	d3.json('../data/simple_ACLED.json')
	.then(ACLEDUnit => {
	 	var geojsonFeature = [];
	 	if (event == "AllEvents")
	 	{
	 		for (var i=0; i<ACLEDUnit.length; i=i+8)
		 	{
		 		var tmpTime = new Date(ACLEDUnit[i].event_date);
		 		if (tmpTime.getTime() >= startTime.getTime() && tmpTime.getTime() <= endTime.getTime())
		 		{
		 			var featureTemp = {
						"type": "Feature",
					    "properties": {
					        "eventType": "1"
					    },
					    "geometry": {
					        "type": "Point",
					        "coordinates": [-104.99404, 39.75621]
					    }
					}
			 		featureTemp.properties.eventType = ACLEDUnit[i].event_type;
			 		featureTemp.geometry.coordinates = [ ACLEDUnit[i].longitude, ACLEDUnit[i].latitude ];
			 		geojsonFeature.push(featureTemp);
		 		}
		 		
		 	}
	 	}	
		else
		{
			for (var i=0; i<ACLEDUnit.length; i++)
		 	{
		 		var tmpTime = new Date(ACLEDUnit[i].event_date);
		 		if (tmpTime.getTime() >= startTime.getTime() && tmpTime.getTime() <= endTime.getTime() && ACLEDUnit[i].event_type == event)
		 		{
		 			var featureTemp = {
						"type": "Feature",
					    "properties": {
					        "eventType": "1"
					    },
					    "geometry": {
					        "type": "Point",
					        "coordinates": [-104.99404, 39.75621]
					    }
					}
			 		featureTemp.properties.eventType = ACLEDUnit[i].event_type;
			 		featureTemp.geometry.coordinates = [ ACLEDUnit[i].longitude, ACLEDUnit[i].latitude ];
			 		geojsonFeature.push(featureTemp);
		 		}
		 		
		 		
		 	}
		}

	 	var colorEvenType = d3.scaleOrdinal().domain(geojsonFeature.map(d => d.properties.eventType))
	    .range(d3.schemePastel1);

	 	console.log(geojsonFeature);
	 	
	 	var geojsonMarkerOptions = {
		    radius: 2,
		    fillColor: "#ff7800",
		    color: "#000",
		    weight: 1,
		    opacity: 0.4,
		    fillOpacity: 0.4
		};

		L.geoJSON(geojsonFeature, {
			pointToLayer: function (feature, latlng) {
				geojsonMarkerOptions.fillColor = colorEvenType(feature.properties.eventType);
		        return L.circleMarker(latlng, geojsonMarkerOptions);
		    }
		}).addTo(map);

	 })
}

//word cloud
function getNowFormatDate(date) {
	var seperator1 = "-";
	var year = date.getFullYear();
	var month = date.getMonth() + 1;
	var strDate = date.getDate();
	if (month >= 1 && month <= 9) {
	month = "0" + month;
	}
	if (strDate >= 0 && strDate <= 9) {
	strDate = "0" + strDate;
	}
	var currentdate = year + seperator1 + month + seperator1 + strDate;
	return currentdate;
}

var color = d3.scaleOrdinal()
        .domain(["PERSON", "LOC", "ORG"])
        .range(["#ff7373", "#4fbd79", "#0a8fd0"]);

var cloudWidth = 290;
var cloudHeight = 345;

function updateWordCloud(eventType, country, startTime, endTime){
	currentCountry.innerHTML = country;
	var formatStartTime = getNowFormatDate(new Date(startTime));
	var formatEndTime = getNowFormatDate(new Date(endTime));
	var frame = currentFrame.innerHTML;
	if (frame == "AllFrames") frame = "null";
	if (eventType == "AllEvents") eventType = "null";
	console.log(frame);
	RSSContent
    	.selectAll("div")
    	.remove();

	RSSContent
    	.selectAll("svg")
    	.remove();

	ACLEDContent
		.selectAll("div")
		.remove();

	ACLEDContent
		.selectAll("svg")
		.remove();

	RSSContent.append("div")
	.text("Loading......");

	ACLEDContent.append("div")
	.text("Loading......");

	d3.json("/timeline/ner_filter_topic_country/null/"+country+"/"+formatStartTime+"/"+formatEndTime)
	.then( wordFrequency => {
		console.log(wordFrequency);
		for (var i=0; i<wordFrequency.length; i++)
		{
			
			wordFrequency[i].size = (Math.log(wordFrequency[i].size)+3)*5;
		}
		console.log(wordFrequency);
		d3.layout.cloud().size([300, 345])
	        .words(wordFrequency)
	        .rotate(0)
	        .text(function(d) { return d.text; })
	        .font("Impact")
	        .padding(2)
	        .fontSize(function(d) { return d.size; })
	        .on("end", drawRSS)
	        .start();  
	});

	d3.json("/acled/ner_filter_topic_country/"+eventType+"/"+country+"/"+formatStartTime+"/"+formatEndTime)
	.then( wordFrequency => {
		console.log(wordFrequency);
		for (var i=0; i<wordFrequency.length; i++)
		{
			/*for (var j=0; j<wordFrequency[i].text.length; j++)
			{
				if (wordFrequency[i].text[j] == " " || wordFrequency[i].text[j] == ".")
				{
					wordFrequency[i].text = wordFrequency[i].text.substring(0,j);
					break;
				}
			}*/
			wordFrequency[i].size = (Math.log(wordFrequency[i].size)+3)*5;
		}
		console.log(wordFrequency);
		d3.layout.cloud().size([300, 345])
	        .words(wordFrequency)
	        .rotate(0)
	        .text(function(d) { return d.text; })
	        .font("Impact")
	        .padding(2)
	        .fontSize(function(d) { return d.size; })
	        .on("end", draw)
	        .start();  
	});

}

function NERfilter(chkBox) {
	var startTime = currentStartTime.innerHTML;
	var endTime = currentEndTime.innerHTML;
	var country = currentCountry.innerHTML;
	var eventType = currentEventType.innerHTML;
	var frame = currentFrame.innerHTML;
	var formatStartTime = getNowFormatDate(new Date(startTime));
	var formatEndTime = getNowFormatDate(new Date(endTime));

	if (chkBox.checked && currentCountry.innerHTML.length!=0) {
		RSSContent
	    	.selectAll("div")
	    	.remove();

		RSSContent
	    	.selectAll("svg")
	    	.remove();

		ACLEDContent
			.selectAll("div")
			.remove();

		ACLEDContent
			.selectAll("svg")
			.remove();

		RSSContent.append("div")
		.text("Loading......");

		ACLEDContent.append("div")
		.text("Loading......");
		if (PERSONCheck != chkBox) PERSONCheck.disabled = true;
		if (LOCATIONCheck != chkBox) LOCATIONCheck.disabled = true;
		if (ORGANIZATIONCheck != chkBox) ORGANIZATIONCheck.disabled = true;
		listCheck.disabled = true;
		if (frame == "AllFrames") frame = "null";
		if (eventType == "AllEvents") eventType = "null";
		d3.json("/acled/ner_filter_topic_country/"+eventType+"/"+country+"/"+formatStartTime+"/"+formatEndTime)
		.then( wordFrequency => {
			var words = [];
			for (var i=0; i<wordFrequency.length; i++)
			{
				if (wordFrequency[i].ner_label == chkBox.value)
				{
					wordFrequency[i].size = (Math.log(wordFrequency[i].size)+3)*5;
					words.push(wordFrequency[i]);
				}
			}
			console.log(words);
			d3.layout.cloud().size([300, 345])
		        .words(words)
		        .rotate(0)
		        .text(function(d) { return d.text; })
		        .font("Impact")
		        .padding(2)
		        .fontSize(function(d) { return d.size; })
		        .on("end", draw)
		        .start();  
		});

		d3.json("/timeline/ner_filter_topic_country/null/"+country+"/"+formatStartTime+"/"+formatEndTime)
		.then( wordFrequency => {
			var words = [];
			for (var i=0; i<wordFrequency.length; i++)
			{
				if (wordFrequency[i].ner_label == chkBox.value)
				{
					wordFrequency[i].size = (Math.log(wordFrequency[i].size)+3)*5;
					words.push(wordFrequency[i]);
				}
			}
			console.log(words);
			d3.layout.cloud().size([300, 345])
		        .words(words)
		        .rotate(0)
		        .text(function(d) { return d.text; })
		        .font("Impact")
		        .padding(2)
		        .fontSize(function(d) { return d.size; })
		        .on("end", drawRSS)
		        .start();  
	});

	}
	else
	{
		if (!chkBox.checked && currentCountry.innerHTML.length!=0)
		{
			PERSONCheck.disabled = false;
			LOCATIONCheck.disabled = false;
			ORGANIZATIONCheck.disabled = false;
			listCheck.disabled = false;
			updateWordCloud(eventType, country, startTime, endTime);
		}
	}
}

function FrameMap (key)
{
	for (var i=0; i<FrameStructure.length; i++)
	{
		for (var j=0; j<FrameStructure[i].children.length; j++)
		{
			if (FrameStructure[i].children[j] == key)
			{
				return FrameStructure[i].name;
			}
		}
	}
}

function ListView(chkBox) {
	var startTime = currentStartTime.innerHTML;
	var endTime = currentEndTime.innerHTML;
	var country = currentCountry.innerHTML;
	var eventType = currentEventType.innerHTML;
	var formatStartTime = getNowFormatDate(new Date(startTime));
	var formatEndTime = getNowFormatDate(new Date(endTime));
	if (chkBox.checked && currentCountry.innerHTML.length!=0) {
		document.getElementById("RSSContent").style.overflow="scroll";
		document.getElementById("ACLEDContent").style.overflow="scroll";
		RSSContent
	    	.selectAll("div")
	    	.remove();

		RSSContent
	    	.selectAll("svg")
	    	.remove();

		ACLEDContent
			.selectAll("div")
			.remove();

		ACLEDContent
			.selectAll("svg")
			.remove();

		RSSContent.append("div")
		.text("Loading......");

		ACLEDContent.append("div")
		.text("Loading......");

		PERSONCheck.disabled = true;
		LOCATIONCheck.disabled = true;
		ORGANIZATIONCheck.disabled = true;

		d3.json("/timeline/list_view/"+formatStartTime+"/"+formatEndTime)
		.then( listContent => {
			console.log(listContent);
			RSSContent
		    	.selectAll("div")
		    	.remove();

		    var showContent = [];

	    	for (var i=0; i<listContent.length; i++)
	    	{
		    	if (listContent[i].location == country) 
		    	{
		    		showContent.push(listContent[i]);
		    	}
	    	}
		    
		    console.log(showContent);

			for (var i=0; i<showContent.length; i++)
			{
				var ContentDiv = document.createElement("div");
				ContentDiv.style.border = "1px solid";
				var text = document.createElement("p");
				text.style.textAlign = "left";
				text.innerHTML = showContent[i].title;
				document.getElementById("RSSContent").appendChild(ContentDiv);
				var Frames = document.createElement("div");
				Frames.style.overflow = "hidden";
				ContentDiv.appendChild(text);
				ContentDiv.appendChild(Frames);
				for (var key of Object.keys(showContent[i].frame_label))
				{
					var FrameDiv = document.createElement("div");
					FrameDiv.style.float = "left";
					FrameDiv.style.height = "15px";
					if (showContent[i].frame_label[key]*15 < 15)
					{
						FrameDiv.style.width = "15px";
					}
					else 
						if (showContent[i].frame_label[key]*15 > 255)
						{
							FrameDiv.style.width = "255px";
						}
						else FrameDiv.style.width = showContent[i].frame_label[key]*15 +"px";
					FrameDiv.style.backgroundColor = colorParent(FrameMap(key));
					FrameDiv.style.marginLeft = "2px";
					FrameDiv.style.marginBottom = "2px";
					Frames.appendChild(FrameDiv);

				}
			}
		});

		d3.json("/acled/list_view/"+formatStartTime+"/"+formatEndTime)
		.then( listContent => {
			console.log(listContent);
			ACLEDContent
		    	.selectAll("div")
		    	.remove();

		    console.log(country, eventType);

		    var showContent = [];

		    if (eventType == "AllEvents")
		    {
		    	for (var i=0; i<listContent.length; i++)
		    	{
			    	if (listContent[i].country == country) 
			    	{
			    		showContent.push(listContent[i]);
			    	}
		    	}
		    }
		    else
		    {
		    	for (var i=0; i<listContent.length; i++)
		    	{
			    	if (listContent[i].country == country && listContent[i].event_type == eventType) 
			    	{
			    		showContent.push(listContent[i]);
			    	}
		    	}
		    }
		    
		    console.log(showContent);

		    ACLEDContent
		    .selectAll('div')
		    .data(showContent)
		    .enter()
		    .append("div")
		    .style("text-align", "left")
		    .style("border", "1px solid")
		    .style("background-color", function(d) { return ACLEDcolor(d.event_type); })
		    //.append("text")
		    .text(function(d) { 
				return d.notes; 
			})

		});
	}
	else
	{
		if (!chkBox.checked && currentCountry.innerHTML.length!=0)
		{
			document.getElementById("RSSContent").style.overflow="hidden";
			document.getElementById("ACLEDContent").style.overflow="hidden";
			PERSONCheck.disabled = false;
			LOCATIONCheck.disabled = false;
			ORGANIZATIONCheck.disabled = false;
			RSSContent
		    	.selectAll("div")
		    	.remove();
	    	ACLEDContent
	    		.selectAll("div")
		    	.remove();
			updateWordCloud(eventType, country, startTime, endTime);
		}
	}
	
}

function draw(words) {

    ACLEDContent
    	.selectAll("svg")
    	.remove();

    ACLEDContent
    	.selectAll("div")
    	.remove();

	var wordCloudSvg = ACLEDContent.append("svg")
		.attr("width", cloudWidth)
	    .attr("height", cloudHeight)
	    .attr("class", "wordcloud");

    wordCloudSvg
        .append("g")
        .attr("transform", 'translate(146, 174)')
        .selectAll("text")
        .data(words)
        .enter().append("text")
        .style("font-size", function(d) { return d.size + "px"; })
        .attr('font-family', 'Impact')
        .style("fill", function(d) { return color(d.ner_label); })
        .attr("text-anchor", "middle")
        .attr("transform", function(d) {
            return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
        })
        .text(function(d) { return d.text; });
}

function drawRSS(words) {

    RSSContent
    	.selectAll("svg")
    	.remove();

    RSSContent
    	.selectAll("div")
    	.remove();

	var wordCloudSvg = RSSContent.append("svg")
		.attr("width", cloudWidth)
	    .attr("height", cloudHeight)
	    .attr("class", "wordcloud");

    wordCloudSvg
        .append("g")
        .attr("transform", 'translate(146, 174)')
        .selectAll("text")
        .data(words)
        .enter().append("text")
        .style("font-size", function(d) { return d.size + "px"; })
        .attr('font-family', 'Impact')
        .style("fill", function(d) { return color(d.ner_label); })
        .attr("text-anchor", "middle")
        .attr("transform", function(d) {
            return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
        })
        .text(function(d) { return d.text; });
}

  
