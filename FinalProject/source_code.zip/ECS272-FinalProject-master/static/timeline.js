var HTimeLine = {
    _focusBox: null,
    _currentLabel: "AllFrames",
    drawTimeLineTree: null,
    _dataRange: [new Date(2016,01,01), new Date(2018,01, 01)],
    _BDA: [7, 1, 7],
    setDateRange: function(d1, d2) {
        this._dataRange = [d1, d2];
        this.drawTimeLineTree(this._currentLabel);
    },
    setFocusBox:function(d1, d2){
        this._focusBox = [d1, d2];
        this.drawTimeLineTree(this._currentLabel);
    },
    clearFocusBox: function() {
        this._focusBox = null;
        this.drawTimeLineTree(this._currentLabel);
    },
    BDAScrollOnChange: function() {
        var beforeInput = document.getElementById("BDA-before-day-input");
        var duringInput = document.getElementById("BDA-during-day-input");
        var afterInput = document.getElementById("BDA-after-day-input");
        var beforeDay = beforeInput.value;
        var duringDay = duringInput.value;
        var afterDay = afterInput.value; 
        this._BDA = [beforeDay, duringDay, afterDay];
        this.drawTimeLineTree(this._currentLabel);
    }
};
(function(){
    var computeBDAmean = function(data) {
        var oneDay = (new Date(2020, 1, 2)) - (new Date(2020, 1, 1));
        var dates = data.map(d=>d.date);        
        var ret = []
        var jdx = 0;
        var meanFunc = (arr) => arr.length===0?0:arr.reduce((a, d)=>a+d, 0) / arr.length;
        for (var idx = 0;idx < dates.length;++idx){
            var beforeArr = []
            jdx = idx-1;
            while ((jdx >= 0) && (dates[idx] - dates[jdx] <= oneDay * HTimeLine._BDA[0])){
                beforeArr.push(data[jdx].value);
                jdx --;
            }
            var beforeMean = meanFunc(beforeArr);
            jdx = idx;
            var duringArr = []
            while ((jdx < dates.length) && (dates[jdx] - dates[idx] < oneDay * HTimeLine._BDA[1])){
                duringArr.push(data[jdx].value);
                jdx ++;
            }
            var duringMean = meanFunc(duringArr);
            jdx = idx + 1;
            var afterArr = []
            while ((jdx < dates.length) && (dates[jdx] - dates[idx] <= oneDay * HTimeLine._BDA[2])){
                afterArr.push(data[jdx].value);
                jdx ++;
            }
            var afterMean = meanFunc(afterArr);
            ret.push( {
                date: dates[idx],
                before: beforeMean,
                during: duringMean,
                after: afterMean
            });
        }
        return ret;
    };
    var alphaRange = function(values, alpha = 0.05) {
        alpha = alpha / 2;
        var sortedValues = values.sort((a, b)=> a- b);
        var lowerBound = sortedValues[Math.floor(values.length * alpha)];
        var upperBound = sortedValues[Math.ceil(values.length * (1-alpha))];
        return [lowerBound, upperBound];    
    };
    var BDAClassifier = function(BDAMean, BDRange, DARange) {
        var ret = [];
        for (var idx=0;idx<BDAMean.length;++idx){
            var before = BDAMean[idx].before;
            var during = BDAMean[idx].during;
            var after = BDAMean[idx].after;
            var date = BDAMean[idx].date;
            var bddiff = before - during;
            var dadiff = during - after;
            var label = 'nochange';
            // if (bddiff > BDRange[0] && bddiff < BDRange[1] && dadiff > DARange[0] && dadiff < DARange[1]){
            //increase
            if (bddiff > BDRange[0] && bddiff < BDRange[1] && dadiff <= DARange[0]) {
                label = 'increase1';
            }
            if (bddiff <= BDRange[0] && dadiff > DARange[0] && dadiff < DARange[1]) {
                label = 'increase2';
            }
            if (bddiff <= BDRange[0] && dadiff <= DARange[0]) {
                label = 'increase3';
            }
            // decrease
            if (bddiff > BDRange[0] && bddiff < BDRange[1] && dadiff >= DARange[1]) {
                label = 'decrease1';
            }
            if (bddiff >= BDRange[1] && dadiff > DARange[0] && dadiff < DARange[1]) {
                label = 'decrease2';
            }
            if (bddiff >= BDRange[1] && dadiff >= DARange[1]) {
                label = 'decrease3';
            }
            //oscillating
            if (bddiff >= BDRange[1] && dadiff <= DARange[0]) {
                label = 'oscillating2';
            }
            if (bddiff <= BDRange[0] && dadiff >= DARange[1]) {
                label = 'oscillating1';
            }
            ret.push({date: date, label: label});
        }
        return ret;
    };
    var drawTimeLine = function(label, data, xAxisFunc, svg, margin, height, width) {
        var totalRange = alphaRange(data.map(d=>d.value));
        var filteredData = data.filter(d => d.date >= HTimeLine._dataRange[0] && d.date <= HTimeLine._dataRange[1]);
        var outliersData = filteredData.filter(d=> ((d.value <= totalRange[0]) || (d.value >= totalRange[1])) && (d.value > 0));
        //console.log(label, outliersData);
        var BDAMean = computeBDAmean(data);
        var BDRange = alphaRange(BDAMean.map(d=>d.before - d.during));
        var DARange = alphaRange(BDAMean.map(d=>d.during - d.after));
        var BDAResult = BDAClassifier(BDAMean, BDRange, DARange);
        BDAResult = BDAResult.filter(d => d.date >= HTimeLine._dataRange[0] && d.date <= HTimeLine._dataRange[1]);
        var BDAColorFunc = function (d) {
            if (d.label === "nochange"){
                return "white";
            } else if (d.label == "increase1"){
                return "rgba(0, 0, 220, 0.7)";
            } else if (d.label == "increase2"){
                return "rgba(0, 0, 180, 0.7)";
            } else if (d.label == "increase3"){
                return "rgba(0, 0, 140, 0.7)";
            } else if (d.label == "decrease1"){
                return "rgba(0, 220, 0, 0.7)";
            } else if (d.label == "decrease2"){
                return "rgba(0, 180, 0, 0.7)";
            } else if (d.label == "decrease3"){
                return "rgba(0, 140, 0, 0.7)";
            } else if (d.label == "oscillating1") {
                return "rgba(255, 165, 0, 0.7)";
            } else if (d.label == "oscillating2") {
                return "rgba(235, 105, 0, 0.7)";
            }
        };
        var innerBottomTopMargin = (margin.bottom - margin.top) * 0.2;
        var y = d3.scaleLinear()
                .domain([0, d3.max(data, d => d.value)]).nice()
                .range([margin.bottom - innerBottomTopMargin, margin.top + innerBottomTopMargin]);
        var yAxis = g => g
                .attr("transform", `translate(${margin.left},0)`)
                .call(d3.axisLeft(y).ticks(5));
        svg.append("g").call(yAxis);
        var oneDayLength = xAxisFunc(new Date(2020, 1, 2)) - xAxisFunc(new Date(2020, 1, 1));
        var yMax = y(d3.max(data, d=>d.value));
        svg.append("g")
             .selectAll("rect")
             .data(BDAResult)
             .join("rect")
             .attr("fill", BDAColorFunc)
             .attr("x", d => xAxisFunc(d.date) - oneDayLength /2)
             .attr("width", oneDayLength)
             .attr("y", yMax)
             .attr("height", y(0) - yMax);

        var line = d3.line()
                .x(d => xAxisFunc(d.date))
                .y(d => y(d.value));
        svg.append("path")
            .datum(filteredData)
            .attr("fill", "none")
            .attr("stroke", "black")
            .attr("stroke-width", 1.5)
            .attr("stroke-linejoin", "round")
            .attr("stroke-linecap", "round")
            .attr("d", line); 
        // draw outliers point
        svg.append("g")
            .selectAll("circle")
            .data(outliersData)
            .join("circle")
            .attr("fill", "black")
            .attr("r", 3)
            .attr("cx", d=> xAxisFunc(d.date))
            .attr("cy", (y(0) + yMax)/2);
        var posY = d3.scaleLinear()
                .domain([0, 1]).nice()
                .range([margin.top + innerBottomTopMargin, margin.top]);
        var posArea = d3.area()
                .curve(d3.curveLinear)
                .x(d => xAxisFunc(d.date))
                .y0(posY(0))
                .y1(d => posY(d.pos_score))
        svg.append("path")
            .datum(filteredData)
            .attr("fill", "rgba(250,0,0,0.9)")
            .attr("d", posArea);
        var negY = d3.scaleLinear()
                .domain([-1, 0]).nice()
                .range([margin.bottom, margin.bottom - innerBottomTopMargin]);
        var negArea = d3.area()
                .curve(d3.curveLinear)
                .x(d => xAxisFunc(d.date))
                .y0(negY(0))
                .y1(d => negY(d.neg_score))
        svg.append("path")
            .datum(filteredData)
            .attr("fill", "rgba(0,0,250,0.9)")
            .attr("d", negArea);
        // add brush 
        console.log("Brush range for ", label, [[margin.left, margin.top + innerBottomTopMargin], [width - margin.right, margin.bottom - innerBottomTopMargin]]);
        svg.append("g")
             .attr("class", "brush")
             .call(d3.brushX()
             .extent([[margin.left, margin.top + innerBottomTopMargin], [width - margin.right, margin.bottom - innerBottomTopMargin]])
             .on("end", function() {
                 var extent = d3.event.selection;
                 if (extent[1] - extent[0] < 50) extent = null;
	        if (extent!==null) {
	            HTimeLine.setDateRange(xAxisFunc.invert(extent[0]), xAxisFunc.invert(extent[1]));
	            HTimeLine.clearFocusBox();
	            updateACLEDDonut(xAxisFunc.invert(extent[0]), xAxisFunc.invert(extent[1]));
	            updateFrameDonut(xAxisFunc.invert(extent[0]), xAxisFunc.invert(extent[1]));
                    updateEventDots(currentFrame.innerHTML, currentEventType.innerHTML,xAxisFunc.invert(extent[0]), xAxisFunc.invert(extent[1]));
                    currentStartTime.innerHTML = xAxisFunc.invert(extent[0]);
                    currentEndTime.innerHTML = xAxisFunc.invert(extent[1]);
	        }
	        else {
                    HTimeLine.setDateRange(OriStartTime, OriEndTime);
                    HTimeLine.clearFocusBox();
                    updateACLEDDonut(OriStartTime, OriEndTime);
                    updateFrameDonut(OriStartTime, OriEndTime);
                    updateEventDots(currentFrame.innerHTML, currentEventType.innerHTML, OriStartTime, OriEndTime);
                    currentStartTime.innerHTML = OriStartTime;
                    currentEndTime.innerHTML = OriEndTime;
	        }
             }));

        if (HTimeLine._focusBox !== null) {
            var d1 = HTimeLine._focusBox[0];
            var d2 = HTimeLine._focusBox[1];
            if (d1 < HTimeLine._dataRange[0] || d2 >HTimeLine._dataRange[1]) return; 
            var x1 = xAxisFunc(d1);
            var y1 = margin.top + innerBottomTopMargin / 2;
            var x2 = xAxisFunc(d2);
            var y2 = margin.bottom - innerBottomTopMargin / 2;
            svg.append('rect')
               .attr('x', x1)
               .attr('y', y1)
               .attr('width', x2 - x1).attr('height', y2-y1)
               .attr('fill', 'rgba(0,0,0,0)')
               .attr('stroke', '#2378ae')
               .attr('stroke-width', '3');
        }
    };
    var drawTimeLines = function(data, svg, margin, height, width) {
        var dates = [];
        for (var key in data){
            for (var i=0;i<data[key].length;++i){
                data[key][i].date = Date.parse(data[key][i].date);
                if (data[key][i].date >= HTimeLine._dataRange[0] && data[key][i].date <= HTimeLine._dataRange[1]) {
                    dates.push(data[key][i].date);
                }
            }
        }
        dates = dates.slice().sort((a, b) => a-b);
        var xAxisFunc = d3.scaleUtc()
                          .domain(d3.extent(dates))
                          .range([margin.left, width - margin.right]);
        var xAxis = g => g
                .attr("transform", `translate(0, ${height - margin.bottom})`)
                .call(d3.axisBottom(xAxisFunc).ticks(width / 150).tickSizeOuter(0));
        svg.append("g").call(xAxis);
        var counter = 0;
        var dataKeys = Object.keys(data);
        var sublineHeight = (height - margin.top - margin.bottom) / dataKeys.length;
        for (var key in data) {
            var newMargin = {top: margin.top + counter * sublineHeight,
                             right: margin.right, 
                             bottom: margin.top + (counter + 1) * sublineHeight - 25,
                             left: margin.left};
            drawTimeLine(key, data[key], xAxisFunc, svg, newMargin, height, width);
            counter += 1;
        }
    };
    var drawLabelTree = function(label, subLabels, svg, margin, height, width) {
        var sublineHeight = (height - margin.top - margin.bottom) / subLabels.length;
        var treeWidth = width - margin.right;
        var midWidth = treeWidth / 2;
        var midOffset = midWidth * 0.15;
        var subLabelPoints = []
        for (var idx=0;idx < subLabels.length;++idx){
            subLabelPoints.push({x: midWidth + midOffset, 
                                 y: margin.top + sublineHeight * (idx) + (sublineHeight - 25) * 0.5,
                                 text: subLabels[idx]});
        }
        var subLabelGroup = svg.append("g").selectAll("g")
                     .data(subLabelPoints).enter();

        var rootCoord = {'x': midWidth - midOffset, 'y': (height - margin.top - margin.bottom) / 2};
        var links = [];
        for (var idx=0;idx < subLabelPoints.length;++idx){
            links.push({'source': rootCoord, 'target': subLabelPoints[idx]});
        }
        var linkFunc = d3.linkHorizontal().x(d=>d.x).y(d=>d.y);
        svg.selectAll(null).data(links).enter()
            .append("path")
            .attr("fill", "none")
            .attr("stroke", "#999")
            .attr("d", linkFunc);
        var subLabelCircles = subLabelGroup.append('circle')
                     .attr("class", "timeline-circle")
                     .attr('cx', d=>d.x)
                     .attr('cy', d=>d.y)
                     .attr('r', 5)
                     .attr('style', '#555')
                     .on('click', function(d) {
                         var label = d.text;
                         HTimeLine.drawTimeLineTree(label);
                     })
        var subLabelTexts = subLabelGroup.append('text')
        subLabelTexts.attr('x', d=>d.x + 7)
                    .attr('y', d=>d.y + 4)
                    .text(d=>d.text)
                    .attr("font-size", "10px")
                    .style("font-weight", "bold");
        var rootCircle = svg.append('circle')
                            .attr("class", "timeline-circle")
                            .attr('cx', rootCoord.x)
                            .attr('cy', rootCoord.y)
                            .attr('r', 5)
                            .style('fill', '#555')
                            .on('click', function(d) {
                                HTimeLine.drawTimeLineTree("AllFrames");
                            });
        var rootLabelTexts = svg.append('text');
        rootLabelTexts.attr('x', rootCoord.x - label.length * 8)
                      .attr('y', rootCoord.y + 4)
                      .text(label)
                      .attr("font-size", "10px")
                      .style("font-weight", "bold");
    };
    var actualDrawer = function(data, label){
        const width = 1190; 
        const height = 500;
        d3.select('#timelines > svg').remove();
        const svg = d3.select("#timelines").append("svg")
                      .attr("viewBox", [0, 0, width, height]);
        var marginTimelines = ({top: 20, right: 30, bottom: 30, left: 310});
        drawTimeLines(data, svg, marginTimelines, height, width);
        var marginLabelTree = ({top: 20, right: width - 270, bottom: 30, left: 0});
        var subLabels = Object.keys(data);
        drawLabelTree(label, subLabels, svg, marginLabelTree, height, width);
    };
    var exportDrawer = function(label) {
            HTimeLine._currentLabel = label;
            d3.json('/timeline/get_all_sublabels/' + label)
              .then(function(d) {
                  if (d === null) return;
                  actualDrawer(d, label)
            });
        };
    HTimeLine.drawTimeLineTree = exportDrawer;
    HTimeLine.drawTimeLineTree("AllFrames");
})()
