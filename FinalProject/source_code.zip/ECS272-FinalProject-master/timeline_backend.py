import json
import datetime
import re
with open('data/climate_data/climate_articles_labeled.json') as f:
    climate_articles = json.load(f)
with open('data/climate_data/RSSFrames.json') as f:
    rss_frames = json.load(f)

climate_articles_lookup = {}
label_with_time = []

def parse_date_string(datestr):
    if re.match('\d{4}-\d{2}-\d{2}', datestr) is not None:
        return datetime.datetime.strptime(datestr, '%Y-%m-%d')
    else:
        return datetime.datetime.strptime(datestr, '%Y/%m/%d')
    
def build_sublabel_table(frames, sublabel_table):
    ret = [frames['name']]
    if 'children' in frames:
        for c in frames['children']:
            build_sublabel_table(c, sublabel_table)
            ret.extend(sublabel_table[c['name']])
    sublabel_table[frames['name']] = ret

for item in climate_articles:
    climate_articles_lookup[item['id']] = item
    label = item['frame_label']
    senti_score = item['sentiment']
    if len(label) == 0:
        continue
    score_sum = 0
    for key in label:
        score_sum += label[key]
    for key in label:
        label[key] /= score_sum

    label_with_time.append({
        'id': item['id'],
        'date': parse_date_string(item['date']),
        'label': label,
        'sentiment': senti_score})

label_with_time.sort(key=lambda x: x['date'])
sublabel_table = {}
build_sublabel_table(rss_frames, sublabel_table)
label_keys = list(sublabel_table.keys())


def get_label_score_in_time_range(label_name, start_date, end_date):
    if not (label_name in label_keys):
        return None
    start_date = parse_date_string(start_date)
    end_date = parse_date_string(end_date)
    ret_dict = {}
    pos_scores = {}
    neg_scores = {}
    for item in label_with_time:
        if item['date'] >= start_date and item['date'] <= end_date:
            if not (item['date'] in ret_dict):
                ret_dict[item['date']] = 0
                pos_scores[item['date']] = []
                neg_scores[item['date']] = []
            match_article = False
            for real_label_name in sublabel_table[label_name]:
                if real_label_name in item['label']:
                    ret_dict[item['date']] += item['label'][real_label_name]
                    match_article = True
            if match_article:
                if item['sentiment'] > 0.5:
                    pos_scores[item['date']].append(item['sentiment'])
                elif item['sentiment'] < 0.5:
                    neg_scores[item['date']].append(item['sentiment'])
    ret_values = []
    for pdate in ret_dict:
        pos_score = 0
        if len(pos_scores[pdate]) > 0:
            pos_score = (sum(pos_scores[pdate]) / len(pos_scores[pdate]) - 0.5 ) * 2
        neg_score = 0
        if len(neg_scores[pdate]) > 0:
            neg_score = (sum(neg_scores[pdate]) / len(neg_scores[pdate]) - 0.5 ) * 2
        ret_values.append({
            'date': pdate.strftime("%Y-%m-%d"), 
            'value': ret_dict[pdate],
            'pos_score': pos_score,
            'neg_score': neg_score})
    return ret_values

def get_sub_labels(label):
    def get_sub_labels_impl(label, node):
        if not ('children' in node):
            return None

        if node['name'] == label:
            ret = []
            for item in node['children']:
                ret.append(item['name'])
            return ret
        else:
            for item in node['children']:
                ret = get_sub_labels_impl(label, item)
                if ret is not None:
                    return ret
            return None
    return get_sub_labels_impl(label, rss_frames)

if __name__=="__main__":
    from IPython import embed; embed()
