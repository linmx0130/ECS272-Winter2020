from flask import Flask, render_template, jsonify
from timeline_backend import get_label_score_in_time_range, get_sub_labels, parse_date_string, sublabel_table
import json
import datetime

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('dyn_index.html')

@app.route('/data/<filename>')
def data(filename):
    with open('data/' + filename) as f:
        data = f.readlines()
    ret = "\n".join(data)
    return ret

@app.route('/data/climate_data/<filename>')
def data_climate(filename):
    with open('data/climate_data/' + filename) as f:
        data = f.readlines()
    ret = "\n".join(data)
    return ret

@app.route('/timeline/get_score/<label>')
def timeline_get_score(label):
    ret = get_label_score_in_time_range(label, '2016-01-01', '2019-01-01')
    return jsonify(ret)

@app.route('/timeline/get_all_sublabels/<label>')
def timeline_get_all_sublabels(label):
    sublabels = get_sub_labels(label)
    ret = {}
    if sublabels is None:
        return jsonify(None)
    for key in sublabels:
        ret[key] = get_label_score_in_time_range(key, '2016-01-01', '2019-01-01')
    return jsonify(ret)

@app.route('/timeline/view_through_time/')
def timeline_view_through_time():
    labels = ['AllFrames', 'Cause', 'Motivation', 'Problem', 'Solution']
    labels_via_time = {}
    for now in labels:
        sublabels = get_sub_labels(now)
        for key in sublabels:
            score_in_time = get_label_score_in_time_range(key, '2016-01-01', '2019-01-01')
            for item in score_in_time:
                if item['value'] == 0:
                    continue
                if not (item['date'] in labels_via_time):
                    labels_via_time[item['date']] = {}
                labels_via_time[item['date']][key] = item['value']
    ret = []
    for tp in labels_via_time:
        ret.append({'date': tp, 'frame_labels': labels_via_time[tp]})
    return jsonify(ret)

@app.route('/timeline/ner_filter_topic_country/<topic>/<country>/<start_date>/<end_date>')
def timeline_ner_filter_topic_country(topic, country, start_date, end_date):
    start_date = datetime.datetime.strptime(start_date, "%Y-%m-%d")
    end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d")
    with open('data/climate_data/climate_articles_labeled.json') as f:
        data = json.load(f)
    persons_stat = {}
    orgs_stat = {}
    locs_stat = {}
    for item in data:
        itemdate = parse_date_string(item['date'])
        if (itemdate >= start_date) and (end_date >= itemdate):
            if ((country != item['location']) and (country != "null")):
                continue
            if topic != 'null':
                all_possible_labels = sublabel_table[topic]
                found_target_label = False
                for label in item['frame_label']:
                    if label in all_possible_labels:
                        found_target_label = True
                        break
                if not found_target_label:
                    continue
            for pw in item['ner']['persons']:
                if pw not in persons_stat:
                    persons_stat[pw] = 0
                persons_stat[pw] += 1
            for pw in item['ner']['orgs']:
                if pw not in orgs_stat:
                    orgs_stat[pw] = 0
                orgs_stat[pw] += 1
            for pw in item['ner']['locs']:
                if pw not in locs_stat:
                    locs_stat[pw] = 0
                locs_stat[pw] += 1
    ret = []
    for item in persons_stat:
        ret.append({'text': item, 'size': persons_stat[item], 'ner_label': 'PERSON'})
    for item in orgs_stat:
        ret.append({'text': item, 'size': orgs_stat[item], 'ner_label': 'ORG'})
    for item in locs_stat:
        ret.append({'text': item, 'size': locs_stat[item], 'ner_label': 'LOC'})
    return jsonify(ret)

@app.route('/timeline/list_view/<start_date>/<end_date>')
def timeline_list_view(start_date, end_date):
    start_date = datetime.datetime.strptime(start_date, "%Y-%m-%d")
    end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d")
    with open('data/climate_data/climate_articles_labeled.json') as f:
        data = json.load(f)
    ret = []
    for t in data:
        tdate = parse_date_string(t['date'])
        if (tdate >= start_date) and (end_date >= tdate):
            ret.append(t)
    return jsonify(ret)



@app.route('/acled/list_view/<start_date>/<end_date>')
def acled_list_view(start_date, end_date):
    start_date = datetime.datetime.strptime(start_date, "%Y-%m-%d")
    end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d")
    with open('data/clean_ACLED.json') as f:
        data = json.load(f)
    ret = []
    for t in data:
        tdate = datetime.datetime.strptime(t['date'], "%d %B %Y")
        if (tdate >= start_date) and (end_date >= tdate):
            ret.append({'date': t['date'],
                        'event_type': t['type'],
                        'country': t['country'],
                        'notes': t['notes']})
    return jsonify(ret)

@app.route('/acled/filter_topic_country/<topic>/<country>/<start_date>/<end_date>')
def acled_filter_topic_country(topic, country, start_date, end_date):
    start_date = datetime.datetime.strptime(start_date, "%Y-%m-%d")
    end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d")
    with open('data/clean_ACLED.json') as f:
        data = json.load(f)
    actor_stat = {}
    for item in data:
        itemdate = datetime.datetime.strptime(item['date'], "%d %B %Y")
        if (itemdate >= start_date) and (end_date >= itemdate) and \
          ((topic == item['type']) or (topic == "null")) and \
          ((country == item['country']) or (country == "null")):
            for actor in item['actors']:
                if actor not in actor_stat:
                    actor_stat[actor] = 0
                actor_stat[actor] += 1
    ret = []
    for item in actor_stat:
        if len(item.strip()) > 0:
            ret.append({'text': item, 'size': actor_stat[item]})
    return jsonify(ret)

@app.route('/acled/ner_filter_topic_country/<topic>/<country>/<start_date>/<end_date>')
def acled_ner_filter_topic_country(topic, country, start_date, end_date):
    start_date = datetime.datetime.strptime(start_date, "%Y-%m-%d")
    end_date = datetime.datetime.strptime(end_date, "%Y-%m-%d")
    with open('data/clean_ACLED.json') as f:
        data = json.load(f)
    persons_stat = {}
    orgs_stat = {}
    locs_stat = {}
    for item in data:
        itemdate = datetime.datetime.strptime(item['date'], "%d %B %Y")
        if (itemdate >= start_date) and (end_date >= itemdate) and \
          ((topic == item['type']) or (topic == "null")) and \
          ((country == item['country']) or (country == "null")):
            for pw in item['ner']['persons']:
                if pw not in persons_stat:
                    persons_stat[pw] = 0
                persons_stat[pw] += 1
            for pw in item['ner']['orgs']:
                if pw not in orgs_stat:
                    orgs_stat[pw] = 0
                orgs_stat[pw] += 1
            for pw in item['ner']['locs']:
                if pw not in locs_stat:
                    locs_stat[pw] = 0
                locs_stat[pw] += 1
    ret = []
    for item in persons_stat:
        ret.append({'text': item, 'size': persons_stat[item], 'ner_label': 'PERSON'})
    for item in orgs_stat:
        ret.append({'text': item, 'size': orgs_stat[item], 'ner_label': 'ORG'})
    for item in locs_stat:
        ret.append({'text': item, 'size': locs_stat[item], 'ner_label': 'LOC'})
    return jsonify(ret)


if __name__=="__main__":
    app.run(host='127.0.0.1', port=8000, debug=True)
